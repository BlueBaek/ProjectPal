// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/Service/BTService_UpdateOwnerFollow.h"

#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"

UBTService_UpdateOwnerFollow::UBTService_UpdateOwnerFollow()
{
	NodeName = TEXT("Update Distance To Owner");

	DistanceToOwnerKey.AddFloatFilter(this, GET_MEMBER_NAME_CHECKED(UBTService_UpdateOwnerFollow, DistanceToOwnerKey));
	bShouldFollowKey.AddBoolFilter(this, GET_MEMBER_NAME_CHECKED(UBTService_UpdateOwnerFollow, bShouldFollowKey));
	OwnerLocationKey.AddVectorFilter(this, GET_MEMBER_NAME_CHECKED(UBTService_UpdateOwnerFollow, OwnerLocationKey));

	Interval = 0.1f;
	RandomDeviation = 0.02f;
}

void UBTService_UpdateOwnerFollow::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	// BlackboardKey(기본 키)가 OwnerActor여야 함
	if (BlackboardKey.SelectedKeyName.IsNone())
	{
		return;
	}

	UBlackboardComponent* BB = OwnerComp.GetBlackboardComponent();
	AAIController* AICon = OwnerComp.GetAIOwner();
	if (!BB || !AICon)
	{
		return;
	}

	APawn* Pawn = AICon->GetPawn();
	AActor* OwnerActor = Cast<AActor>(BB->GetValueAsObject(BlackboardKey.SelectedKeyName));

	if (!Pawn || !OwnerActor || OwnerActor == Pawn)
	{
		if (!DistanceToOwnerKey.SelectedKeyName.IsNone())
		{
			BB->SetValueAsFloat(DistanceToOwnerKey.SelectedKeyName, 0.f);
		}
		if (!bShouldFollowKey.SelectedKeyName.IsNone())
		{
			BB->SetValueAsBool(bShouldFollowKey.SelectedKeyName, false);
		}
		if (!OwnerLocationKey.SelectedKeyName.IsNone())
		{
			BB->SetValueAsVector(OwnerLocationKey.SelectedKeyName, FVector::ZeroVector);
		}
		return;
	}

	const FVector PawnLoc  = Pawn->GetActorLocation();
	const FVector OwnerLoc = OwnerActor->GetActorLocation();
	const float Dist = FVector::Dist(PawnLoc, OwnerLoc);

	if (!DistanceToOwnerKey.SelectedKeyName.IsNone())
	{
		BB->SetValueAsFloat(DistanceToOwnerKey.SelectedKeyName, Dist);
	}

	if (!OwnerLocationKey.SelectedKeyName.IsNone())
	{
		BB->SetValueAsVector(OwnerLocationKey.SelectedKeyName, OwnerLoc);
	}

	// bShouldFollow 히스테리시스 (Start > Stop 권장)
	if (!bShouldFollowKey.SelectedKeyName.IsNone())
	{
		const bool bWasFollow = BB->GetValueAsBool(bShouldFollowKey.SelectedKeyName);

		bool bNowFollow = bWasFollow
			? !(Dist <= FollowStopDistance)   // 따라가는 중이면 StopDistance 이하에서만 false
			: (Dist >= FollowStartDistance);  // 안 따라가면 StartDistance 이상에서만 true

		BB->SetValueAsBool(bShouldFollowKey.SelectedKeyName, bNowFollow);
	}

	if (bDebugLog)
	{
		const bool bFollow = bShouldFollowKey.SelectedKeyName.IsNone()
			? false
			: BB->GetValueAsBool(bShouldFollowKey.SelectedKeyName);

		UE_LOG(LogTemp, Log, TEXT("[UpdateOwnerFollow] Owner=%s Dist=%.1f Follow=%s"),
			*OwnerActor->GetName(), Dist, bFollow ? TEXT("true") : TEXT("false"));
	}
}
