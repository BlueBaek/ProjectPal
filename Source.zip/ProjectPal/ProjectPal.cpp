// Copyright Epic Games, Inc. All Rights Reserved.

#include "ProjectPal.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, ProjectPal, "ProjectPal" );
 