// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "PalSkill/PalSkillExecution.h"
#include "PalSkill_GrassTornado.generated.h"

class APJ_GrassTornado;


UCLASS()
class PROJECTPAL_API UPalSkill_GrassTornado : public UPalSkillExecution
{
	GENERATED_BODY()
	
};
