// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Services/BTService_BlackboardBase.h"
#include "BTService_UpdateOwnerFollow.generated.h"

/**
 * 
 */
UCLASS()
class PROJECTPAL_API UBTService_UpdateOwnerFollow : public UBTService_BlackboardBase
{
	GENERATED_BODY()
	
public:
	UBTService_UpdateOwnerFollow();
	
protected:
	// Output keys
	UPROPERTY(EditAnywhere, Category="Blackboard")
	FBlackboardKeySelector DistanceToOwnerKey; // float

	UPROPERTY(EditAnywhere, Category="Blackboard")
	FBlackboardKeySelector bShouldFollowKey;   // bool (선택)

	UPROPERTY(EditAnywhere, Category="Blackboard")
	FBlackboardKeySelector OwnerLocationKey;   // vector (선택)

	// Follow hysteresis
	UPROPERTY(EditAnywhere, Category="Config")
	float FollowStartDistance = 500.f; // 이 이상 멀어지면 따라가기 시작

	UPROPERTY(EditAnywhere, Category="Config")
	float FollowStopDistance  = 250.f; // 이 이하 가까워지면 따라가기 중지 (Start > Stop 권장)

	// 디버그용
	UPROPERTY(EditAnywhere, Category="Debug")
	bool bDebugLog = false;

	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};
